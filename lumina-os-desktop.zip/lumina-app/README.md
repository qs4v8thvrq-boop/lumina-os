# LUMINA OS — Desktop App Build Instructions

## What's inside
- `index.html` — The complete LUMINA OS platform
- `main.js` — Electron wrapper with full native menu
- `package.json` — Build configuration
- `assets/icon.png` — App icon (replace with higher quality if desired)

## Requirements
- Node.js 18+ — https://nodejs.org
- npm (comes with Node.js)

## Build in 3 commands

```bash
# 1. Enter the folder
cd lumina-app

# 2. Install Electron
npm install

# 3. Build for your platform
npm run build-win      # → Windows .exe (portable, no install needed)
npm run build-mac      # → macOS .dmg
npm run build-linux    # → Linux .AppImage
```

Output appears in the `dist/` folder.

## Quick test (before building)
```bash
npm install
npx electron .
```

## What the desktop app includes
- Native app menu: File, Edit, View, Tools, AI, Help
- Keyboard shortcuts: Cmd/Ctrl+S (save), Cmd/Ctrl+O (load), F (place), S (select), A (aim)
- View switching: Cmd/Ctrl+1 (2D), Cmd/Ctrl+2 (3D), Cmd/Ctrl+3 (Section)
- External links open in browser
- Fullscreen support
- Dark title bar matching the UI
- Minimum window size enforced

## Native menu items wired to app functions
- File → Save Project, Load Project, Export IES/LDT/CSV/SKP, Print Report
- Edit → Delete, Clear All
- View → 2D/3D/Section, Zoom In/Out/Fit, Fullscreen, DevTools
- Tools → Select/Place/Aim, Auto Layout, Array, Run Calculation
- AI → Full Analysis, Optimise, Energy, Compliance, Open AI Guide
- Help → ARK / inSona / Lumenlight websites, AS/NZS 1680, NCC Section J

## Custom icon
Replace `assets/icon.png` with a 512×512 PNG before building.
electron-builder will auto-convert to .ico (Windows) and .icns (macOS).

## Partners
ARK Lighting · arklighting.com.au
inSona · insona.com.au  
Lumenlight · lumenlight.com.au
