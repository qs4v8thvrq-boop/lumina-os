const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');

// Keep a global reference to prevent garbage collection
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    title: 'LUMINA OS — Lighting Intelligence Platform',
    backgroundColor: '#010408',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false, // allow loading local fonts/assets
    },
    // Show window controls with dark theme
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    frame: true,
    show: false, // don't show until ready
  });

  // Load the app
  mainWindow.loadFile('index.html');

  // Show window once content is loaded
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Open external links in browser, not Electron
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Application menu
function buildMenu() {
  const template = [
    {
      label: 'LUMINA OS',
      submenu: [
        { label: 'About LUMINA OS', click: () => {
          const { dialog } = require('electron');
          dialog.showMessageBox(mainWindow, {
            type: 'info',
            title: 'LUMINA OS',
            message: 'LUMINA OS v3.1',
            detail: 'Professional Lighting Intelligence Platform\n\nARK Lighting × inSona × Lumenlight\nPowered by Claude AI\n\n© 2025–2026 ARK Lighting Pty Ltd',
          });
        }},
        { type: 'separator' },
        { label: 'Quit LUMINA OS', accelerator: 'CmdOrCtrl+Q', role: 'quit' }
      ]
    },
    {
      label: 'File',
      submenu: [
        { label: 'New Project', accelerator: 'CmdOrCtrl+N', click: () => {
          mainWindow.webContents.executeJavaScript('clearAll()');
        }},
        { label: 'Save Project', accelerator: 'CmdOrCtrl+S', click: () => {
          mainWindow.webContents.executeJavaScript('saveProject()');
        }},
        { label: 'Load Project', accelerator: 'CmdOrCtrl+O', click: () => {
          mainWindow.webContents.executeJavaScript('loadProjectFromFile()');
        }},
        { type: 'separator' },
        { label: 'Export IES Files', click: () => {
          mainWindow.webContents.executeJavaScript('exportIES()');
        }},
        { label: 'Export LDT Files', click: () => {
          mainWindow.webContents.executeJavaScript('exportLDT()');
        }},
        { label: 'Export CSV Schedule', click: () => {
          mainWindow.webContents.executeJavaScript('exportCSV()');
        }},
        { label: 'Export SketchUp Script', click: () => {
          mainWindow.webContents.executeJavaScript('exportSKP()');
        }},
        { type: 'separator' },
        { label: 'Print / PDF Report', accelerator: 'CmdOrCtrl+P', click: () => {
          mainWindow.webContents.executeJavaScript('showReport()');
        }},
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { label: 'Undo', accelerator: 'CmdOrCtrl+Z', role: 'undo' },
        { label: 'Redo', accelerator: 'Shift+CmdOrCtrl+Z', role: 'redo' },
        { type: 'separator' },
        { label: 'Delete Selected Fixture', accelerator: 'Delete', click: () => {
          mainWindow.webContents.executeJavaScript('delSel()');
        }},
        { label: 'Clear All Fixtures', click: () => {
          mainWindow.webContents.executeJavaScript('clearAll()');
        }},
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Plan 2D', accelerator: 'CmdOrCtrl+1', click: () => {
          mainWindow.webContents.executeJavaScript("setView('2d')");
        }},
        { label: '3D Walkthrough', accelerator: 'CmdOrCtrl+2', click: () => {
          mainWindow.webContents.executeJavaScript("setView('3d')");
        }},
        { label: 'Section View', accelerator: 'CmdOrCtrl+3', click: () => {
          mainWindow.webContents.executeJavaScript("setView('section')");
        }},
        { type: 'separator' },
        { label: 'Zoom In', accelerator: 'CmdOrCtrl+=', click: () => {
          mainWindow.webContents.executeJavaScript('zI()');
        }},
        { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', click: () => {
          mainWindow.webContents.executeJavaScript('zO()');
        }},
        { label: 'Fit to Screen', accelerator: 'CmdOrCtrl+0', click: () => {
          mainWindow.webContents.executeJavaScript('zF()');
        }},
        { type: 'separator' },
        { label: 'Toggle Fullscreen', accelerator: 'F11', role: 'togglefullscreen' },
        { label: 'Developer Tools', accelerator: 'F12', click: () => {
          mainWindow.webContents.toggleDevTools();
        }},
      ]
    },
    {
      label: 'Tools',
      submenu: [
        { label: 'Select Tool', accelerator: 'S', click: () => {
          mainWindow.webContents.executeJavaScript("setTool('sel')");
        }},
        { label: 'Place Fixture', accelerator: 'F', click: () => {
          mainWindow.webContents.executeJavaScript("setTool('place')");
        }},
        { label: 'Aim Tool', accelerator: 'A', click: () => {
          mainWindow.webContents.executeJavaScript("setTool('aim')");
        }},
        { type: 'separator' },
        { label: 'Auto Layout', click: () => {
          mainWindow.webContents.executeJavaScript('autoLayout()');
        }},
        { label: 'Array Fixtures…', click: () => {
          mainWindow.webContents.executeJavaScript('showArray()');
        }},
        { type: 'separator' },
        { label: 'Run Calculation', accelerator: 'CmdOrCtrl+R', click: () => {
          mainWindow.webContents.executeJavaScript('runCalc()');
        }},
      ]
    },
    {
      label: 'AI',
      submenu: [
        { label: 'Full Analysis', click: () => {
          mainWindow.webContents.executeJavaScript("runAI('analyse')");
        }},
        { label: 'Optimise Layout', click: () => {
          mainWindow.webContents.executeJavaScript("runAI('optimise')");
        }},
        { label: 'Energy Savings', click: () => {
          mainWindow.webContents.executeJavaScript("runAI('energy')");
        }},
        { label: 'Compliance Check', click: () => {
          mainWindow.webContents.executeJavaScript("runAI('ncc')");
        }},
        { type: 'separator' },
        { label: 'Open AI Guide Panel', click: () => {
          mainWindow.webContents.executeJavaScript('toggleAvPanel()');
        }},
      ]
    },
    {
      label: 'Help',
      submenu: [
        { label: 'ARK Lighting Website', click: () => shell.openExternal('https://www.arklighting.com.au') },
        { label: 'inSona Website', click: () => shell.openExternal('https://insona.com.au') },
        { label: 'Lumenlight Website', click: () => shell.openExternal('https://lumenlight.com.au') },
        { type: 'separator' },
        { label: 'AS/NZS 1680 Standards', click: () => shell.openExternal('https://www.standards.org.au') },
        { label: 'NCC Section J (Energy)', click: () => shell.openExternal('https://ncc.abcb.gov.au') },
      ]
    }
  ];

  // macOS: put app menu first
  if (process.platform === 'darwin') {
    template.unshift({ label: app.name, submenu: template[0].submenu });
    template.splice(1, 1);
  }

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  createWindow();
  buildMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
